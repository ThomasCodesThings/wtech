

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(url('/category/'.$product->productType)); ?>"><?php echo e(ucfirst($product->productType)); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->productTitle); ?></li>
  </ol>
</nav>

<div class="container mb-5" id="container">
        <div class="row" id="productDetails">
          <div class="col-sm-auto">
            <img id="showcase_img" class="mt-2" src="<?php echo e(asset('resources/'.json_decode($product->productImage, true)[0])); ?>">
          </div>
          <div class="col-sm-auto" id="product-div">
              <h2> <?php echo e($product->productTitle); ?></h2>

            <div><span>
              <p>
                <b><?php echo e($product->productPrice); ?> €</b>
              </p>
            </span></div>

          </div>
            <div class="row">
              
            <form action="<?php echo e(route('add-to-cart')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-sm-4 mt-2">
              <p>
                <?php if($product->productAmount > 5): ?>
                In stock!
                <?php elseif($product->productAmount > 0 && $product->productAmount <= 5): ?>
                Only <?php echo e($product->productAmount); ?> left!
                <?php else: ?>
                Out of stock!
                <?php endif; ?>
              </p>
              <?php if($product->productAmount > 0): ?>
              <div class="row row-cols-auto" id="value-box">
              <div class="col">
              <button type="button" class="control-btn btn-dark btn-sm" onclick="if(document.getElementById('number_input').value > 0){document.getElementById('number_input').value--}">-</button>
              </div>
                <div class="col">
              <input type="number" class="form-control-sm" id="number_input" name="amount" value="1" min="1">
              </div>
              <div class="col">
              <button type="button" class="control-btn btn-dark btn-sm" onclick="document.getElementById('number_input').value++">+</button>
              <!--<button type="button" class="control-btn" onclick="if(document.getElementById('number_input').value < <?php echo e($product->productAmount); ?>){document.getElementById('number_input').value++}">+</button>-->
              </div>
              </div">
              <?php endif; ?>
            </div>
            </div>
            <?php if($product->productAmount > 0): ?>
            <div class="row">  
              <div class="col">
                <input type="hidden" name="product" value="<?php echo e($product); ?>">
                <button type="submit" class="add_to_cart btn-sm btn-dark mt-1 mb-1">Add to cart</button>
              </div>
            </div>
            <?php endif; ?>
            </form>

          </div>
          </div>

          <div class="row row-cols-auto">
            <button type="button" class="btn-sm btn-dark mt-1 mb-1" id="desc-brn" onclick="document.getElementById('product-galery').style.display = 'none'; document.getElementById('product-description').style.display = 'block';">Description</button>
            <button type="button" class="btn-sm btn-dark mt-1 mb-1" id="galery-btn" onclick="document.getElementById('product-description').style.display = 'none'; document.getElementById('product-galery').style.display = 'block';">Galery</button>
          </div>
         <div class="row">
           <hr>
          <div class="row" id="product-galery">
          <?php if(count(json_decode($product->productImage, true)) > 0): ?>
            <div class="galery">
              <div class="modal" id="modal">
              <img class="modal-content" id="modal_img">
              <span class="close" id="close">&times;</span> 
              </div> 
              <div class="col-sm-auto"> 
              <?php $__currentLoopData = json_decode($product->productImage, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <img src="<?php echo e(asset('resources/'.$image)); ?>" class="mt-1 mb-1" id="product_img" onclick="display(this)">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
          </div>
          </div>
          <div class="row" id="product-description">
          <p>
          <?php echo e($product->productdetail); ?>

          </p>
          </div>
          </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/page/product.blade.php ENDPATH**/ ?>