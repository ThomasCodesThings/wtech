

<?php $__env->startSection('content'); ?>
<h1>Edit product</h1>
<hr>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('products', [$product->id])); ?>" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="_method" value="PUT">
    <?php echo e(csrf_field()); ?>


    <div class="form-group mb-3">
        <label for="title">Product title</label>
        <input type="text" value="<?php echo e($product->productTitle); ?>" class="form-control" id="productTitle"  name="productTitle">
    </div>

    <div class="form-group mb-3">
        <label for="productBrand">Brand</label>
        <input type="text" value="<?php echo e($product->productBrand); ?>" class="form-control" id="productBrand"  name="productBrand">
    </div>

    <div class="form-group mb-3">
        <label for="productPrice">Price</label>
        <input type="text" value="<?php echo e($product->productPrice); ?>" class="form-control" id="productPrice"  name="productPrice">
    </div>

    <div class="form-group mb-3">
        <label for="productAmount">Amount</label>
        <input type="text" value="<?php echo e($product->productAmount); ?>" class="form-control" id="productAmount"  name="productAmount">
    </div>

    <div class="form-check mb-3">
        <?php if($product->productDiscount == false): ?>
            <input class="form-check-input" type="checkbox" id="productDiscount" name="productDiscount">
            <label class="form-check-label" for="productDiscount">Discount item</label>
        <?php else: ?>
            <input class="form-check-input" type="checkbox" id="productDiscount" name="productDiscount" checked>
            <label class="form-check-label" for="productDiscount">Discount item</label>
        <?php endif; ?>
    </div>

    <div class="form-group mb-3">
        <label for="title">Details</label>
        <input type="textarea" value="<?php echo e($product->productDetail); ?>" class="form-control" id="productDetail"  name="productDetail">
    </div>

    <div class="form-group form-group-sm mb-3">
        <label  for="productType">Product type</label>
        <select class="form-control" name="productType" id="productType" value="<?php echo e($product->productType); ?>">
            <option value="householdgoods">Household goods</option>
            <option value="toiletries">Toiletries</option>
            <option value="craft">Craft</option>
        </select>
    </div>

    <label for="img">Images</label>
    <div class="input-group hdtuto control-group lst" id="img">
        <input type="file" name="filenames[]" class="myfrm form-control mb-3" multiple>
    </div>
    <button type="submit" class="btn btn-dark mb-3">Change</button>
</form>

<div class="container-fluid text-start">
        <div class="row d-flex justify-content-start">
        <?php $__currentLoopData = json_decode($product->productImage, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-auto">
                    <img class="product border border-secondary mb-3" src="<?php echo e(asset('resources/'.$image)); ?>">
                    <form action="<?php echo e(route('delete', ['product' => $product, 'image'=> $image])); ?>" method="POST">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" class="btn btn-danger mb-3" value="Remove"/>
                    </form>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/admin/editproduct.blade.php ENDPATH**/ ?>