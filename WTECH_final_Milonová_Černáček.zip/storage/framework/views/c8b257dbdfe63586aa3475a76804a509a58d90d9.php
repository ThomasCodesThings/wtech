

<?php $__env->startSection('content'); ?>
<h1>Editácia úlohy</h1>
<hr>
<form action="<?php echo e(url('coupons', [$coupon->id])); ?>" method="POST">
	<input type="hidden" name="_method" value="PUT">
    <?php echo e(csrf_field()); ?>


    <div class="form-group mb-3">
        <label for="title">Coupon code</label>
        <input type="text" class="form-control" id="coupon_code"  name="coupon_code" value="<?php echo e($coupon->coupon_code); ?>">
    </div>

    <div class="form-group mb-3">
        <label for="productBrand">Discount</label>
        <input type="text" class="form-control" id="Discount"  name="discount" value="<?php echo e($coupon->discount); ?>">
    </div>

    <div class="form-group mb-3">
        <label for="productPrice">Valid until</label>
        <input type="text" class="form-control" id="valid_until"  name="valid_until" placeholder="dd/mm/yyyy" value="<?php echo e($coupon->valid_until); ?>">
    </div>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Change</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/admin/editcoupon.blade.php ENDPATH**/ ?>