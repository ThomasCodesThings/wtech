

<?php $__env->startSection('content'); ?>
<form action="/checkouts" method="post">
    <input type="hidden" name="total" value="<?php echo e($total); ?>">
    <?php echo e(csrf_field()); ?>

        <div class="row overflow-fix row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1 ">
            <h1>Checkout</h1>
            <div class="col col-lg-7 col-md-7 col-sm-12 overflow-fix">
                <section class="w-90 p-3 border">

                    <legend>Personal information</legend>
                    
                        <label for="name">Name</label>
                        <?php if(auth()->guard()->check()): ?>
                        <input type="name" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
                        <?php else: ?>
                        <input type="name" class="form-control" id="name" name="name" placeholder="Adam Podolský" value="<?php echo e(old('name')); ?>">
                        <?php endif; ?>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-alert">Please fill in your name for delivery.</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="form-group form-group-sm mt-3">
                            <label for="email">Email address</label>
                            <?php if(auth()->guard()->check()): ?>
                            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" value="<?php echo e($user->email); ?>">
                            <?php else: ?>
                            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
                            <?php endif; ?>
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-alert">Please fill in your email to receive info about delivery.</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
        
                        <label for="telephone" class="mt-3">Telephone number</label>
                        <div class="input-group input-group-sm">
                                <div class="input-group-prepend">
                                <select class="form-control" id="presets" name="preset" value="<?php echo e(old('preset')); ?>">
                                    <option>+421</option>
                                    <option>+420</option>
                                    <option>+43</option>
                                    <option>+48</option>
                                    <option>+49</option>
                                </select>
                                </div>
                            <input type="text" class="form-control" id="telephone" aria-describedby="basic-addon3" name="phone" value="<?php echo e(old('phone')); ?>">
                        </div>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error-alert">Please fill in your phone number.</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <legend>Address</legend>
                        <div class="form-group mt-3">
                            <label for="countries">Country</label>
                            <select class="form-control" id="countries" name="country" value="<?php echo e(old('country')); ?>">
                            <option>Slovakia</option>
                            <option>Czech</option>
                            <option>Austria</option>
                            <option>Germany</option>
                            <option>Poland</option>
                            </select>
                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-alert">Please fill in your country.</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row">
                            <div class="form-group form-group-sm mt-3 col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4">
                                <label for="day">Region</label>
                                <input type="text" class="form-control" id="day" placeholder="Bratislavský kraj" name="region" value="<?php echo e(old('region')); ?>">
                                <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-alert">Please fill in your region.</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
        
                            <div class="form-group form-group-sm mt-3 col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4">
                                <label for="month">Town</label>
                                <input type="text" class="form-control" id="month" placeholder="Bratislava" name="town" value="<?php echo e(old('town')); ?>">
                                <?php $__errorArgs = ['town'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-alert">Please fill in your town.</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
        
                            <div class="form-group form-group-sm mt-3 col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4">
                                <label for="year">Postal code</label>
                                <input type="text" class="form-control" id="year" placeholder="82104" name="postalCode" value="<?php echo e(old('postalCode')); ?>">
                                <?php $__errorArgs = ['postalCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-alert">Please fill in your postal code without blank spaces.</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
        
                        <div class="form-group form-group-sm mt-3">
                            <label for="street">Street</label>
                            <input type="text" class="form-control" id="street" placeholder="Antolská" name="street" value="<?php echo e(old('street')); ?>">
                            <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-alert">Please fill your street name.</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
        
                        <div class="form-group mt-3">
                            <label for="details">Additional details</label>
                            <textarea class="form-control" id="details" rows="3" name="details" value="<?php echo e(old('details')); ?>"></textarea>
                        </div>
                    </section>
            </div>
        
            <div class="col col-lg-5 col-md-5 col-sm-12 d-flex justify-content-center overflow-fix">
                <section class="w-100">
                    <div class="border p-3">
                        <legend>Checkout</legend>
                        <hr class="my-4" style="width:100%">
                        <div class="d-flex justify-content-between">
                            <div>Delivery</div>
                            <div class="mr-3 mb-3">5 $</div>
                        </div>
                        <?php if($total != $oldTotal): ?>
                        <div class="d-flex justify-content-between">
                            <div>Product price(before discount)</div>
                            <div class="mr-3 mb-3"> <?php echo e($oldTotal); ?>$</div>
                        </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between">
                            <div>Product price</div>
                            <div class="mr-3 mb-3"> <?php echo e($total); ?>$</div>
                        </div>
                        <hr class="my-4" style="width:100%">
                        <div class="d-flex justify-content-between">
                            <div>Total</div>
                            <div class="mr-3 mb-3"><?php echo e($total + 5); ?> $</div>
                        </div>
                        <div class="d-flex justify-content-center mt-1">
                            <button type="submit" class="btn btn-dark w-100">Order</button>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <div class="row overflow-fix row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1 ">

            <div class="col col-lg-7 col-md-7 col-sm-12 overflow-fix">
                <section class="w-90 p-3 border marg mt-3">
                    <legend>Payment method</legend>

                    <div class="row overflow-fix row-cols-lg-4 row-cols-md-2 row-cols-sm-4 row-cols-2">
                        <div class="col">
                            <i class="fas fa-credit-card fa-5x" id="CC"></i>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" id="cc" name="payment" value='creditCard' <?php if(old('payment')== "creditCard") { echo 'checked'; } ?> >
                                <label class="form-check-label" for="cc">Credit card</label>
                            </div>
                        </div>
                        <div class="col">
                            <i class="fab fa-cc-visa fa-5x" id="visa"></i>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" id="visa" name="payment" value='visa' <?php if(old('payment')== "visa") { echo 'checked'; } ?> >
                                <label class="form-check-label" for="visa">Visa</label>
                            </div>
                        </div>
                        <div class="col">
                            <i class="fab fa-cc-paypal fa-5x " id="PP"></i>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" id="pp" name="payment" value= 'payPal' <?php if(old('payment')== "payPal") { echo 'checked'; } ?> >
                                <label class="form-check-label" for="pp">Pay pal</label>
                            </div>
                        </div>
                        <div class="col">
                            <i class="fas fa-money-bill fa-5x" id="cash"></i>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" id="cash" name="payment" value='cash' <?php if(old('payment')== "cash") { echo 'checked'; } ?> >
                                <label class="form-check-label" for="cash">Pay in cash</label>
                            </div>
                        </div>
                    </div>
                </section>
                <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-alert">Please select type of payment.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <section class="w-90 p-3 border marg mt-3">
                    <legend>Delivery details</legend>

                    <div class="form-check border pt-1 pb-1 mb-3 d-flex justify-content-between">
                        <input class="form-check-input ms-1" type="radio" id="clk" name="delivery" value="CC" <?php if(old('delivery')== "CC") { echo 'checked'; } ?> >
                        <label class="form-check-label ms-1" for="clk">Click & collect</label>
                        <i class="fas fa-mouse me-3"></i>
                    </div>

                    <div class="form-check border pt-1 pb-1 mb-3 d-flex justify-content-between">
                        <input class="form-check-input ms-1" type="radio" id="hd" name="delivery" value="HD" <?php if(old('delivery')== "HD") { echo 'checked'; } ?> >
                        <label class="form-check-label ms-1" for="hd">Home delivery</label>
                        <i class="fas fa-home me-3"></i>
                    </div>

                    <div class="form-check border pt-1 pb-1 mb-3 d-flex justify-content-between">
                        <input class="form-check-input ms-1" type="radio" id="ls" name="delivery" value="LS" <?php if(old('delivery')== "LS") { echo 'checked'; } ?> >
                        <label class="form-check-label ms-1" for="ls">Locker system</label>
                        <i class="fas fa-key me-3"></i>
                    </div>
                </section>
                <?php $__errorArgs = ['delivery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-alert">Please select type of delivery.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button type="submit" class="btn btn-dark w-100 mt-3">Order</button>
            </div>
        </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpage_wt_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/page/checkout.blade.php ENDPATH**/ ?>