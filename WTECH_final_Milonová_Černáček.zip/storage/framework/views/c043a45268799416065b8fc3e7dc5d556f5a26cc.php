
<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Craft</li>
  </ol>
</nav>
<h1 class="overflow-fix title">Craft</h1>
<hr class="my-4">
<div class="container-fluid overflow-fix w-100" id="filter_container">
          <h4>Filter</h4>
          <form method="get" action="<?php echo e(url('craft')); ?>">
          <?php echo csrf_field(); ?>
          <div class="container-fluid overflow-fix" id="filter_settings">
            <h5>Price</h5>
            <div class="row">
            <div class="col-sm-1" id="priceCol">
            <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label"><h7>From €</h7></label>
                    <input name="priceFrom" type="text" class="form-control" id="priceFrom" placeholder="">
                  </div>
            </div>
            <div class="col-sm-auto">
              <p>0</p>
            </div>  
            <div class="col-sm-9" id="priceRange">
                    <input type="range" class="form-range" id="priceFromRange" min="0", max="<?php echo e($maxPrice); ?>">
                  </div>
          <div class="col-sm-auto">
              <p><?php echo e($maxPrice); ?></p>
            </div> 
            </div>
            <div class="row">
            <div class="col-sm-1" id="priceCol">
            <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label"><h7>To €</h7></label>
                    <input name="priceTo" type="text" class="form-control" id="priceTo" placeholder="">
                  </div>
            </div>
            <div class="col-sm-auto">
              <p>0</p>
            </div>  
            <div class="col-sm-9" id="priceRange">
                    <input type="range" class="form-range" id="priceToRange" min="0", max="<?php echo e($maxPrice); ?>">
                  </div>
          <div class="col-sm-auto">
              <p><?php echo e($maxPrice); ?></p>
            </div> 
            </div>  
                    <div class="row">
                      <hr>
                    </div>
                    <div class="row">
                      <h5>Brands</h5>
                    </div>
                    <div class="row">
                      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-sm-auto">
                        <div class="brand">
                          <input type="checkbox" name="brands[]" value="<?php echo e($brand); ?>">
                          <label for="<?php echo e($brand); ?>"> <?php echo e($brand); ?> </label>
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <input type="checkbox" id="discount" name="discount" value="true">
                      <label for="discount">Discount products only</label>
                      <div class ="row">
                      <hr>
                      <div class="col-sm-2">
                        <button type="submit">Submit</button>
                        </div>
                      </div>
                    </div>
                    <!--<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <input type="hidden" name="products[]" value="<?php echo e($product); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                    </form>
                    <form method="get" action="<?php echo e(url('craft')); ?>">
                      <?php echo csrf_field(); ?>
                      <select name="per-page" onfocus="this.selectedIndex = 0";>
                      <option value="2">2</option>
                        <option value="4">4</option>
                        <option value="6">6</option>
                        <option value="8">8</option>
                        <option value="16">16</option>
                        <option value="32">32</option>
                        <option value="64">64</option>
                      </select>
                      <select name="order" onfocus="this.selectedIndex = 0";>
                        <option value="asc">Ascending</option>
                        <option value="desc">Descending</option>
                      </select>
                      <button type="submit">Sort</button>
                    </form>
              </div>


<div class="row d-flex justify-content-start overflow-fix">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="product text-center col-auto mb-3">
                            <a class="d-block" href="<?php echo e(url('craft/'.$product->id)); ?>">
                                <img class="product border border-secondary" src="<?php echo e(asset('resources/'.json_decode($product->productImage, true)[0])); ?>">
                                <p class="product"><?php echo e($product->productTitle); ?></p>
                            </a>
                            <div class="container">
                                <div class="row row-cols-lg-2 row-cols-md-2 row-cols-sm-2 row-cols-1 no-gutters">
                                    <div class="col">
                                        <p class="product text-center"><data value="50"><?php echo e($product->productPrice); ?></data>$</p>
                                    </div>
                                    <div class="col">
                                        <a href="/buy/" class="product text-center">Buy</a> 
                                    </div>
                                </div>
                            </div>
                        </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($products->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpage_wt_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/page/craft.blade.php ENDPATH**/ ?>