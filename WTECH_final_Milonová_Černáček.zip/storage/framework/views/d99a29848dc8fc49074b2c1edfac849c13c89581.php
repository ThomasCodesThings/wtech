

<?php $__env->startSection('content'); ?>
<h1>Coupon details </h1>
<div class="jumbotron">
	<div class="h5">Coupon code</div>
    <p>
		<?php echo e($coupon->coupon_code); ?> 
    </p>

    <div class="h5">Discount</div>
    <p>
		<?php echo e($coupon->discount); ?> 
    </p>

	<div class="h5">Valid until</div>
	<p>
		<?php echo e($coupon->valid_until); ?>

	</p>

    <div class="d-grid gap-2 newline">
    <a class="btn btn-warning ms-0" href="<?php echo e(URL::to('coupons/' . $coupon->id . '/edit')); ?>">Edit</a>&nbsp;&nbsp;
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/admin/showcoupon.blade.php ENDPATH**/ ?>