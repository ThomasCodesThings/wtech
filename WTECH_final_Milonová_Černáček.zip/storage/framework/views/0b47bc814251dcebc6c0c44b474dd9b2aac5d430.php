
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/global.css')); ?>">
    <meta charset="utf-8"><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/layout/partials/head.blade.php ENDPATH**/ ?>