
 
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
	<h1>Products</h1>
    <table class="table">
        <thead class="thead-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Product type</th>
                <th scope="col">Price</th>
                <th scope="col">Brand</th>
                <th scope="col">Amount</th>
                <th scope="col">Discount</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($product->id); ?></th>
                <td><a href="/products/<?php echo e($product->id); ?>"><?php echo e($product->productTitle); ?></a></td>
                <td><?php echo e($product->productType); ?></td>
                <td><?php echo e($product->productPrice); ?></td>
                <td><?php echo e($product->productBrand); ?></td>
                <td><?php echo e($product->productAmount); ?></td>
                <?php if($product->productDiscount == true): ?>
                    <td><i class="fas fa-check"></i></td>
                <?php else: ?>
                    <td><i class="fas fa-times"></i></td>
                <?php endif; ?>
                <td>
                <form action="<?php echo e(url('products', [$product->id])); ?>" method="POST">
                    <input type="hidden" name="_method" value="DELETE">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="submit" class="btn btn-danger" value="Delete"/>
                </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/admin/viewproducts.blade.php ENDPATH**/ ?>