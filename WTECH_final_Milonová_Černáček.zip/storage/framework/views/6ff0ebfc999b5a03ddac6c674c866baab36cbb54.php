
<?php $__env->startSection('content'); ?>
<h1 class="overflow-fix title">Results for "<?php echo e($search); ?>" </h1>
<hr class="my-4">

<div class="row d-flex justify-content-between overflow-fix">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="product text-center col-auto mb-3">
                                <a class="d-block" href="<?php echo e(url('/'.$product->id)); ?>">
                                <img class="product border border-secondary" src="<?php echo e(asset('resources/'.json_decode($product->productImage, true)[0])); ?>">
                                <p class="product"><?php echo e($product->productTitle); ?></p>
                            </a>
                            <div class="container">
                                <div class="row row-cols-lg-2 row-cols-md-2 row-cols-sm-2 row-cols-1 no-gutters">
                                    <div class="col">
                                        <p class="product text-center"><data value="50"><?php echo e($product->productPrice); ?></data>$</p>
                                    </div>
                                    <div class="col">
                                    <form action="<?php echo e(route('add-to-cart')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product" value="<?php echo e($product); ?>">
                                    <input type="hidden" name="amount" value="1">
                                    <a href="javascript:;" onclick="parentNode.submit();" class="product text-center">Buy</a> 
                                    </form> 
                                    </div>
                                </div>
                            </div>
                        </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="d-flex justify-content-center ms-5">
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/page/search.blade.php ENDPATH**/ ?>