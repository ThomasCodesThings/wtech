

<?php $__env->startSection('content'); ?>
<h1>Add new coupon</h1>
<hr>
<form action="/coupons" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group mb-3">
        <label for="title">Coupon code</label>
        <input type="text" class="form-control" id="coupon_code"  name="coupon_code">
    </div>

    <div class="form-group mb-3">
        <label for="productBrand">Discount</label>
        <input type="text" class="form-control" id="Discount"  name="discount">
    </div>

    <div class="form-group mb-3">
        <label for="productPrice">Valid until</label>
        <input type="text" class="form-control" id="valid_until"  name="valid_until" placeholder="dd/mm/yyyy">
    </div>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/admin/createcoupon.blade.php ENDPATH**/ ?>