<!doctype html>
<html lang="en">
<head>
    <title>I♥home</title>
    <?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layout.partials.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main role="main" class ="height">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('layout.partials.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layout.partials.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html> <?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/layout/mainpage_wt_banner.blade.php ENDPATH**/ ?>