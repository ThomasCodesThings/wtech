

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->productTitle); ?></li>
  </ol>
</nav>

<div class="container" id="container">
        <div class="row" id="productDetails">
          <div class="col-sm-auto">
            <img src="<?php echo e(asset('resources/'.json_decode($product->productImage, true)[0])); ?>">
          </div>
          <div class="col-sm-6" id="test">
              <h2> <?php echo e($product->productTitle); ?></h2>

            <div class="row">
              <p>
                <?php echo e($product->productdetail); ?>

              </p>
            </div>
        </div>
            <div class="row">
              
            <div class="col-sm-4">
              <p>
                <b><?php echo e($product->productPrice); ?> €</b>
              </p>
            </div>
            <form action="<?php echo e(route('add-to-cart')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-sm-4 mt-2">
              <p>
                <?php if($product->productAmount > 5): ?>
                In stock!
                <?php elseif($product->productAmount > 0 && $product->productAmount <= 5): ?>
                Only <?php echo e($product->productAmount); ?> left!
                <?php else: ?>
                Out of stock!
                <?php endif; ?>
              </p>
              <?php if($product->productAmount > 0): ?>
              <input type="number" name="amount" value="1" min="0" max="<?php echo e($product->productAmount); ?>">
              <?php endif; ?>
            </div>
            </div>
            <?php if($product->productAmount > 0): ?>
            <div class="row">  
              <input type="hidden" name="product" value="<?php echo e($product); ?>">
              <button type="submit" class="add_to_cart">Add to cart</button>
            </div>
            <?php endif; ?>
            </form>

          </div>
          </div>
          
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/page/home_product.blade.php ENDPATH**/ ?>