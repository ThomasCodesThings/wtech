
 
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
	<h1>Coupons</h1>
    <table class="table">
        <thead class="thead-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Coupon code</th>
                <th scope="col">Discount</th>
                <th scope="col">Valid until</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($coupon->id); ?></th>
                <td><a href="/coupons/<?php echo e($coupon->id); ?>"><?php echo e($coupon->coupon_code); ?></a></td>
                <td><?php echo e($coupon->discount); ?></td>
                <td><?php echo e($coupon->valid_until); ?></td>
                <td>
                        <form action="<?php echo e(url('coupons', [$coupon->id])); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="submit" class="btn btn-danger" value="Delete"/>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/admin/viewcoupons.blade.php ENDPATH**/ ?>