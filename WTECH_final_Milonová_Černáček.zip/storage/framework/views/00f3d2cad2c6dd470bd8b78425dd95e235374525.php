<!doctype html>
<html lang="en">
<head>
    <title>I♥home</title>
    <?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
<?php echo $__env->make('layout.partials.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<main role="main" class="container">
  
  <div class="admin-template">
      <div class="row">
          <div class="col-sm-12">
              <?php echo $__env->yieldContent('content'); ?>
          </div>
      </div>
  </div>

</main>
  
    <?php echo $__env->make('layout.partials.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html> <?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/layout/adminpage.blade.php ENDPATH**/ ?>