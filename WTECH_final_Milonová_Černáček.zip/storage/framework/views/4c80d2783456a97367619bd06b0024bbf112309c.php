

<?php $__env->startSection('content'); ?>
<h1>Product details: <?php echo e($product->title); ?></h1>
<div class="jumbotron">
	<div class="h5">Title</div>
    <p>
		<?php echo e($product->productTitle); ?> 
  </p>

	<div class="h5">Price</div>
	<p>
		<?php echo e($product->productPrice); ?>

	</p>

    <div class="h5">Brand</div>
    <p>
		<?php echo e($product->productBrand); ?> 
    </p>

    <div class="h5">Amount</div>
    <p>
		<?php echo e($product->productAmount); ?> 
    </p>

    <div class="h5">Discount</div>
    <?php if($product->productDiscount == true): ?>
      <p><i class="fas fa-check"></i></p>
    <?php else: ?>
      <p><i class="fas fa-times"></i></p>
    <?php endif; ?>

    <div class="h5">Details</div>
    <p>
		<?php echo e($product->productDetail); ?> 
    </p>

    <div class="h5">Type</div>
    <p>
		<?php echo e($product->productType); ?> 
    </p>

    <div class="h5">Images</div>
  <?php $__currentLoopData = json_decode($product->productImage, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <img class="product border border-secondary mb-3" src="<?php echo e(asset('resources/'.$image)); ?>">
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="d-grid gap-2 newline">
    <a class="btn btn-warning mb-5  ms-0" href="<?php echo e(URL::to('products/' . $product->id . '/edit')); ?>">Edit</a>&nbsp;&nbsp;
    </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/admin/showproduct.blade.php ENDPATH**/ ?>