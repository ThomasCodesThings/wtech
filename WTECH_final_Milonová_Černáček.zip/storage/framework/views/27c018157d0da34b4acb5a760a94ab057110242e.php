
<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Household goods</li>
  </ol>
</nav>
<div class="container-fluid overflow-fix w-100" id="filter_container">

          <h4>Filter</h4>
          <form method="get" action="<?php echo e(url('/category/householdgoods')); ?>">
          <?php echo csrf_field(); ?>
          <div class="container-fluid overflow-fix" id="filter_settings">
            <h5>Price</h5>
            <div class="row">
            <div class="col-sm-1" id="priceCol">
            <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label"><h7>From €</h7></label>
                    <input name="priceFrom" type="text" class="form-control" id="priceFrom" placeholder="" value="<?php echo e(old('priceFrom')); ?>">
                  </div>
            </div>
            <div class="col-sm-auto">
              <p>0</p>
            </div>  
            <div class="col-sm-9" id="priceRange">
                    <input type="range" class="form-range" id="priceFromRange" min="0", max="<?php echo e($maxPrice); ?>", value="<?php echo e(old('priceFrom')); ?>">
                  </div>
          <div class="col-sm-auto">
              <p><?php echo e($maxPrice); ?></p>
            </div> 
            </div>
            <div class="row">
            <div class="col-sm-1" id="priceCol">
            <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label"><h7>To €</h7></label>
                    <input name="priceTo" type="text" class="form-control" id="priceTo" placeholder="", value="<?php echo e(old('priceTo')); ?>">
                  </div>
            </div>
            <div class="col-sm-auto">
              <p>0</p>
            </div>  
            <div class="col-sm-9" id="priceRange">
                    <input type="range" class="form-range" id="priceToRange" min="0", max="<?php echo e($maxPrice); ?>", value="<?php echo e(old('priceTo')); ?>">
                  </div>
          <div class="col-sm-auto">
              <p><?php echo e($maxPrice); ?></p>
            </div> 
            </div>  
                    <div class="row">
                      <hr>
                    </div>
                    <div class="row">
                      <h5>Brands</h5>
                    </div>
                    <div class="row">
                      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-sm-auto">
                        <div class="brand">
                          <input type="checkbox" name="brands[]" value="<?php echo e($brand); ?>"
                          <?php echo e((is_array(old('brands')) && in_array($brand, old('brands'))) ? ' checked' : ''); ?>

                          >
                          <label for="<?php echo e($brand); ?>"> <?php echo e($brand); ?> </label>
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <input type="checkbox" id="discount" name="discount" value="true"
                      <?php echo e((old('discount') == true) ? ' checked' : ''); ?>

                      >
                      <label for="discount">Discount products only</label>
                      <div class ="row">
                      <hr>
                      <div class="col-sm-2">
                        <button type="submit">Submit</button>
                        </div>
                      </div>
                    </div>

                      <select name="per-page" onchange="this.form.submit();" onfocus="this.selectedIndex = -1";>
                      <option value="2"
                      <?php echo e((old('per-page') == 2) ? ' selected' : ''); ?>>2</option>
                        <option value="4"
                        <?php echo e((old('per-page') == 4) ? ' selected' : ''); ?>>4</option>
                        <option value="6"
                        <?php echo e((old('per-page') == 6) ? ' selected' : ''); ?>>6</option>
                        <option value="8"
                        <?php echo e((old('per-page') == 8) ? ' selected' : ''); ?>>8</option>
                        <option value="16"
                        <?php echo e((old('per-page') == 16) ? ' selected' : ''); ?>>16</option>
                        <option value="32"
                        <?php echo e((old('per-page') == 32) ? ' selected' : ''); ?>>32</option>
                        <option value="64"
                        <?php echo e((old('per-page') == 64) ? ' selected' : ''); ?>>64</option>
                      </select>
                      <select name="order" onchange="this.form.submit();" onfocus="this.selectedIndex = -1";>
                        <option value="asc"
                        <?php echo e((old('order') == "asc") ? ' selected' : ''); ?>>Ascending</option>
                        <option value="desc"
                        <?php echo e((old('order') == "desc") ? ' selected' : ''); ?>>Descending</option>
                      </select>
                      
                    </form>
              </div>


<div class="row d-flex justify-content-start overflow-fix">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="product text-center col-auto mb-3">
                            <a class="d-block" href="<?php echo e(url('/'.$product->id)); ?>">
                                <img class="product border border-secondary" src="<?php echo e(asset('resources/'.json_decode($product->productImage, true)[0])); ?>">
                                <p class="product"><?php echo e($product->productTitle); ?></p>
                            </a>
                            <div class="container">
                                <div class="row row-cols-lg-2 row-cols-md-2 row-cols-sm-2 row-cols-1 no-gutters">
                                    <div class="col">
                                        <p class="product text-center"><data value="50"><?php echo e($product->productPrice); ?></data>$</p>
                                    </div>
                                    <div class="col">
                                    <form action="<?php echo e(route('add-to-cart')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product" value="<?php echo e($product); ?>">
                                    <input type="hidden" name="amount" value="1">
                                    <a href="javascript:;" onclick="parentNode.submit();" class="product text-center">Buy</a> 
                                    </form> 
                                    </div>
                                </div>
                            </div>
                        </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="fix-pagination-a">
<?php echo e($products->links()); ?>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainpage_wt_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tomáš Černáček\Documents\webpage\resources\views/pages/page/householdgoods.blade.php ENDPATH**/ ?>